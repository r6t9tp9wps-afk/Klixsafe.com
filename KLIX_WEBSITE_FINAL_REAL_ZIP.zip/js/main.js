
function toggleMenu(){document.getElementById('nav').classList.toggle('open');}
function sendQuote(e){
  e.preventDefault();
  const q={
    name:document.getElementById('name').value,
    phone:document.getElementById('phone').value,
    email:document.getElementById('email').value,
    product:document.getElementById('product').value,
    quantity:document.getElementById('quantity').value,
    message:document.getElementById('message').value
  };
  const body=`Hello KLIX,%0D%0A%0D%0AI would like a wholesale quote.%0D%0A%0D%0AName/Company: ${q.name}%0D%0APhone/WhatsApp: ${q.phone}%0D%0AEmail: ${q.email}%0D%0AProduct: ${q.product}%0D%0AQuantity: ${q.quantity}%0D%0AMessage: ${q.message}`;
  window.location.href=`mailto:Klix.safe@gmail.com?subject=Wholesale Quote Request&body=${body}`;
}
